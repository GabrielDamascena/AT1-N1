import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';

export default function App() {
    const [seconds, setSeconds] = useState(0);
    const [isRunning, setIsRunning] = useState(false);

    useEffect(() => {
        let interval = null;
        if (isRunning) {
            interval = setInterval(() => {
                setSeconds(prevSeconds => prevSeconds + 1);
            }, 1000);
        } else if (!isRunning && seconds !== 0) {
            clearInterval(interval);
        }
        return () => clearInterval(interval);
    }, [isRunning, seconds]);

    const formatTime = (seconds) => {
        const hrs = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    };

    const pad = (num) => {
        return num < 10 ? '0' + num : num;
    };

    return (
        <View style={styles.container}>
            <Text style={styles.timer}>{formatTime(seconds)}</Text>
            <View style={styles.buttonContainer}>
                <Button title={isRunning ? "Pausar" : "Iniciar"} onPress={() => setIsRunning(!isRunning)} />
                <Button title="Zerar" onPress={() => { setIsRunning(false); setSeconds(0); }} />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    timer: {
        fontSize: 48,
        marginBottom: 20,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '60%',
    },
});