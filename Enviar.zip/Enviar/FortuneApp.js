import React, { useState } from 'react';
import { StyleSheet, Text, View, Image, Button } from 'react-native';

export default function App() {
  const [isBroken, setIsBroken] = useState(false);

  const handlePress = () => {
    setIsBroken(true);
  };

  return (
    <View style={styles.container}>
      <Image
        source={
          isBroken
            ? require('./assets/biscoito_aberto.jpg')
            : require('./assets/biscoito_fechado.png')
        }
        style={styles.image}
      />
      {isBroken && <Text style={styles.message}>Você terá uma surpresa agradável em breve!</Text>}
      <Button title="Abrir Biscoito da Sorte" onPress={handlePress} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },
  message: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
});
