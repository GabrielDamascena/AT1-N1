import React, { useState } from 'react';
import { StyleSheet, Text, View, Image, Button } from 'react-native';

export default function App() {
  const [quote, setQuote] = useState(quotes[0]);

  const getRandomQuote = () => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    setQuote(quotes[randomIndex]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.quoteText}>"{quote.text}"</Text>
      <Text style={styles.authorText}>- {quote.author}</Text>
      <Image source={quote.image} style={styles.image} />
      <Button title="Nova Citação" onPress={getRandomQuote} />
    </View>
  );
}
export const quotes = [
  {
    text: "A única maneira de fazer um ótimo trabalho é amar o que você faz.",
    author: "Steve Jobs",
    image: require('./src/assets/Steve_Jobs.jpg')
  },
  {
    text: "O sucesso é ir de fracasso em fracasso sem perder o entusiasmo.",
    author: "Winston Churchill",
    image: require('./src/assets/winston_churchill.jpg')
  },
  {
    text: "Quanto mais nos elevamos, menores parecemos aos olhos daqueles que não sabem voar.",
    author: "Friedrich Nietzsche",
    image: require('./src/assets/Friedrich_Nietzsche.jpg')
  },
  {
    text: "É fazendo que se aprende a fazer aquilo que se deve aprender a fazer.",
    author: "Aristóteles",
    image: require('./src/assets/aristoteles.jpg')
  },
  
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },
  quoteText: {
    fontSize: 24,
    fontStyle: 'italic',
    textAlign: 'center',
    marginBottom: 20,
  },
  authorText: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
});